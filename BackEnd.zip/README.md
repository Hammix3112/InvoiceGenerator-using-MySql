# Invoice-Generator-MERN-Project
It is a full stack project of a invoice generator
